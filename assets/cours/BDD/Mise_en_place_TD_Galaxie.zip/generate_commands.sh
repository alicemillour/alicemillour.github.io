echo 'Modifier le script avec les informations de connexion à mysql'

sed -e 's/\s/_/g' etudiants.txt | sed -e 's/^\(.*\)$/create database BDD_L3_\1_QUETE ;/g' > create_databases.sql


sed -e 's/\s/_/g' etudiants.txt | sed -e 's/^\(.*\)$/mysql -u<User> -p<Password> BDD_L3_\1_QUETE < import TD_galaxie.sql/g' > import_databases.sql


