create database BDD_L3_AMOR_SABRINA_QUETE ;
create database BDD_L3_BALLARIS_EMMA_QUETE ;
create database BDD_L3_BIGEON_CLARA_QUETE ;
