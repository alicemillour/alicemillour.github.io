########## Création des bases pour les étudiants ##############

Le fichier TD_galaxie.sql contient la base de données initiale nécessaire pour faire le TD. 
Pour que chaque étudiant puisse avoir sa base de travail, on récupère les noms prénoms sur la liste d'émargement au format suivant (voir fichier etudiants.txt)

"
NOM1 PRÉNOM1
NOM2 PRÉNOM2
...
"

Le script generate_sql_commands.sh génère deux fichiers contenant les scripts SQL nécessaires à la création (fichier create_databases.sql) et l'initialisation (fichier import_databases.sql) des bases des étudiants. Il faut modifier le script avec les informations de la BDD avant de l'utiliser.

Ce script bash n'est pas infaillible, je n'ai pas testé de cas limite, donc il faut vérifier les fichiers générés. 

Il suffit ensuite d'exécuter les scripts SQL dans phpMyAdmin.
