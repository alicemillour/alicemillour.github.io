mysql -u<User> -p<Password> BDD_L3_AMOR_SABRINA_QUETE < import TD_galaxie.sql
mysql -u<User> -p<Password> BDD_L3_BALLARIS_EMMA_QUETE < import TD_galaxie.sql
mysql -u<User> -p<Password> BDD_L3_BIGEON_CLARA_QUETE < import TD_galaxie.sql
