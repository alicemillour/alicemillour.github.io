# -*- coding: utf-8 -*-

def affiche_et_remplace():
    """
    Affiche les nombre de 0 à 100 et remplace 
        - les multiples de 3 par 'divisible par 3'
        - les multiples de 5 par 'divisible par 5'
        - les multiples de 3 et 5 par 'divisible par 3 et par 5'
    """
    for i in range(101):
	    if i%3 == 0 and i%5 == 0:
	        # on doit commencer par cette condition car elle inclut 
	        # les deux suivantes 
	        print("divisible par 3 et par 5")
	    elif i%3 == 0:
	        print("divisible par 3")
	    elif i%5 == 0:
	        print("divisible par 5")
	    else:
	        print(i)
    return
    
def infos():
    print("""
            ===============================================
                           Affiche et remplace 
            ===============================================
            """)
	

if __name__ == "__main__":
    infos()
    affiche_et_remplace()
