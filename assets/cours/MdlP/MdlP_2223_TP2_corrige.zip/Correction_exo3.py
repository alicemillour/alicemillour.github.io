# -*- coding: utf-8 -*-

def fib(n):
    if n == 1:
        return [1]
    if n == 2:
        return [1, 1]
    l = [1, 1]
    for _ in range(2, n):
        l.append(l[-1] + l[-2])
    return l


if __name__ == "__main__":
    nb_fibo = int(input("Quelle est la valeur de n souhaitée ?\n"))
    print(fib(nb_fibo))
#    print(fib(1))  # [1]
#    print(fib(2))  # [1, 1]
#    print(fib(3))  # [1, 1, 2]
#    print(fib(10)) # [1, 1, 2, 3, 5, 8, 13, 21, 34, 55]

