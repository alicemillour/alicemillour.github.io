#include <stdio.h>
#include <stdlib.h>

int main() {
    int n, sum = 0;
    printf("Entrez la taille du tableau : ");
    scanf("%d", &n);

    // Allocation dynamique
    int* arr = (int*) malloc(n * sizeof(int));
    if (arr == NULL) {
        printf("Échec de l'allocation de mémoire\n");
        return 1;
    }

    // Lecture des valeurs
    for (int i = 0; i < n; i++) {
        printf("Entrez un entier : ");
        scanf("%d", &arr[i]);
        sum += arr[i];
    }

    printf("Somme des éléments : %d\n", sum);

    // Libération de la mémoire
    free(arr);
    return 0;
}

