// Source : https://beej.us/guide/bgc/html/#passvalue
#include <stdio.h>
int *p;


int main()
{
    // Prints size of an 'int'
    printf("int : %zu\n", sizeof(int));    
    
    // Prints size of a 'float'
    printf("float : %zu\n", sizeof(float));
    
    // Prints size of a 'char'
    printf("char : %zu\n", sizeof(char));

    // p is type 'int *', so prints size of 'int*'
    printf("pointer : %zu\n", sizeof(p));

    // *p is type 'int', so prints size of 'int'
    printf("object int* p points on : %zu\n", sizeof(*p));
    return 0;
}
