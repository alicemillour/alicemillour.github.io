#include <stdio.h>

int incrementer_return(int x) {
    printf("x au début de l'appel à incrementer: %d\n", x);
    x = x + 1; // Ne modifie que la copie locale de x
    return x;
}

void incrementer_sans_return(int* p) {
    printf("*p au début de l'appel à incrementer: %d\n", *p);
    *p = *p + 1; // Ne modifie que la copie locale de x
    return;
}

void affiche(char c) {
    printf("%c", c);
}

int main() {
    int a = 5;
    printf("a avant appel de incrementer avec return: %d\n", a); // 
    a = incrementer_return(a);
    printf("a après appel de incrementer avec return: %d\n", a); //
    printf("-----\n"); 
    printf("a avant appel de incrementer sans return: %d\n", a); // 
    incrementer_sans_return(&a);
    printf("a après appel de incrementer sans return: %d\n", a); // 
    return 0;
}
