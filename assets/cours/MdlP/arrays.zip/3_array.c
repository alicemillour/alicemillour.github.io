#include <stdio.h>

int main(void)
{
    int i;
    float f[5];  // Declare an array of 4 floats

    f[0] = 0.14159;  // Indexing starts at 0, of course.
    f[1] = 1.41421;
    f[2] = 2.61803;
    f[3] = 3.71828;
    f[4] = 4.74588;

    // Print them all out:

    for (i = 0; i < 5; i++) {
        printf("%f\n", f[i]);
    }
    
    // Get the size of the array: 
    printf("sizeof f : %zu\n", sizeof(f));     // 48 total bytes
    printf("sizeof float : %zu\n", sizeof(float));  // 4 bytes per int

    printf("f/int = number of elements : %zu\n", sizeof(f) / sizeof(int));  // 48/4 = 12 ints!
    
    // use length: 
    int length = sizeof(f) / sizeof(int);
    
    
    for (i = 0; i < length; i++) {
        printf("%f\n", f[i]);
    }
    
    // Array's address :
    printf("&f : %p\n", &f);
    // Dereference array :
    printf("*f : %f\n", *f);
    
    // Dereference array (4th element):
    printf("*f+4 : %f\n", *(f+4));
    // Dereference array (4th element):
    printf("&f+4*sizeof(float) : %f\n", *(&f+4*sizeof(float)));
    
    
}
