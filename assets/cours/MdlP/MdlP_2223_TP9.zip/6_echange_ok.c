#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>

/* 1. compléter le code en remplaçant les "??"
   2. ajouter les affichages permettant de 
   montrer que l'échange a fonctionné
 */


void echange(uint32_t *a, uint32_t *b)
{
	/* afficher les valeurs initiales des paramètres 
    et des données vers lesquelles elles pointent */
    uint32_t t = *a; 
    *a = *b; 
    *b = t; 
}

int main(void)
{
    uint32_t x = 17;
    uint32_t y = 42;
    
    echange(??, ??); // ici on passe les adresses !
    
    return EXIT_SUCCESS;
}
    
