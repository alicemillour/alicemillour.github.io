#include <stdio.h>
/* 1. exécuter le code et
observer les différents affichages
   2. saisir différentes valeurs pour i
   et observer les changements
 */

void main()
{
  unsigned int i;
  printf("entrez un entier sous forme hexadecimale i = ");
  scanf("%x", &i);
  printf("i = %d\n", i);
}

