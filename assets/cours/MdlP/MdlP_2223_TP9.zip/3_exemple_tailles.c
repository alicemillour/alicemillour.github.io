#include <stdio.h> 

/* 1. remplacer les ?? et rajoutez les appels
à printf manquant pour faire afficher
la taille en octet des différents types :
- unsigned char
- char
- unsigned int
- int
- long double

2. vérifier que les tailles t1 et t2 des adresses 
de deux types de taille différents sont bien 
égales (t1 == t2) 
*/


void main()

{

printf("\n %ld octets pour variable de type char ",sizeof(??));

} 
