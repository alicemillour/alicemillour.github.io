#include <stdio.h>


/* ajouter les affichages permettant de 
   comprendre ce que fait le code
   (que valent i, j, p1 et p2 à la fin ?)
 */

void main()
{
  int i = 3, j = 6;
  int *p1, *p2;
  p1 = &i;
  p2 = &j;
  p1 = p2;
}

