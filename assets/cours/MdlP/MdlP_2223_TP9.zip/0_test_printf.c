#include <stdio.h>


/* 1. exécuter le code et
observer les différents affichages
   2. modifier les valeurs de i et j et observer
les changements
 */

void main()
{
  int i = 23674;
  int j = -23674;
  char c = 'A';
  char *chaine = "test";

  printf("impression de i: \n");
  printf("%d \t %u \t %x",i,i,i); // 23674  23674   5c7a
  printf("\nimpression de j: \n");
  printf("%d \t %u \t %x",j,j,j); // -23674 4294943622  ffffa386
  printf("\nimpression de c: \n");
  printf("%c \t %d",c,c); // A  65
  printf("\nimpression de chaine: \n");
  printf("%s",chaine); // test
  printf("\n");
}
