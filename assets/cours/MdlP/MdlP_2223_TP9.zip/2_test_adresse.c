#include <stdio.h>

/*
1. Remplacer les ?? 
2. Expérimentez différentes valeurs de x
pour voir le résultat
3. Que se passe-t-il si x vaut un entier
supérieur à 2^32-1 ? 
essayez avec 2^32 = 4294967296
ou 2^32+1.
*/


int main() {
  /* ce bout de code
  permet de savoir si l'architecture 
  de la machine sur laquelle vous vous
  trouvez est de type little ou big
  endian
  */ 
  int n = 1;
  if(*(char *)&n == 1) {
    printf("Little Endian\n");
  } else {
    printf("Big Endian\n");
  }

  int x = 255; 

  printf("Valeur de la variable x  : ??\n", ??);
  printf("taille de la variable x : %ld\n", sizeof(x));
  
  printf("Adresse de la variable x : ??\n", ??);
  printf("taille de l'adresse : %ld\n", sizeof(??));
  
  /* on définit ci-dessous la liste des 
  octets occupés par la variable x*/
  unsigned char * liste_octets = (unsigned char*) &x;
  
 for (int i=0 ; i<sizeof(x) ; i++){
      /* Parcours de la liste et affichage des octets */
      printf("la valeur dans case %d (adresse %p) est %x (taille %ld)\n", i,
      liste_octets+i, liste_octets[i], sizeof(liste_octets[i]));
 }
}
