#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>

/* ajouter les affichages permettant de 
montrer que l'échange a été réalisé dans 
la fonction mais que les valeurs de x et de y
sont inchangées */

void echange_faux(uint32_t a, uint32_t b)
{
    uint32_t t = a;
    a = b;
    b = t;
}

int main(void)
{
    uint32_t x = 17;
    uint32_t y = 42;
    echange_faux(x, y);
    
    return EXIT_SUCCESS;
}

