import random

nombre_machine = random.randint(1, 20)

def devine():
    cherche_encore = True
    # on fait chercher l'utilisateur⋅ice
    # tant que le nombre n'a pas été trouvé
    while cherche_encore  == True:
        choix = int(input("Tentez de deviner le nombre : "))
        if choix < nombre_machine:
            print("Trop petit.")
        elif choix > nombre_machine:
            print("Trop grand.")
        else:
            print("Bravo ! ")
            cherche_encore = False
            
if __name__ == "__main__":
    devine()
    # comment ajouter la possiblité d'afficher le nombre de tentatives faites par l'utilisateur ?
