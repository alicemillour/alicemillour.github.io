# -*- coding: utf-8 -*-

def affiche_et_remplace():
    
    for i in range(20):
        if i%3 == 0 and i%5 == 0:
            print("divisible par 3 et par 5")
        elif i%3 == 0:
            print("divisible par 3")
        elif i%5 == 0:
            print("divisible par 5")
        else:
            print(i)
    return
    
if __name__ == "__main__":
    affiche_et_remplace()
