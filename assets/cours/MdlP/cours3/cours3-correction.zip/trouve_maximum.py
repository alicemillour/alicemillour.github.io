def trouve_maximum_3(a, b, c):
    print("début de la fonction trouve_maximum")
    # comparaison de deux premiers nombres
    if a > b:
        max = a
        # seconde comparaison
        if a > c:
            max = a
        else:
            max = c
    else:
        max = b
        # seconde comparaison (2è option)
        if b > c:
            max = b 
        else :
            max = c
    return max
    
def trouve_maximum_3bis(a, b, c):
    max = trouve_maximum(a, b)
    max = trouve_maximum(max, c)
    return(max)

def trouve_maximum(a, b):
    print("début de la fonction trouve_maximum")
    if a > b:
        return a
    else:
        return b
	# notez que l'instruction ci-dessous
	# ne s'affiche pas car elle vient après 
	# l'instruction "return b"
    print("fin de la fonction trouve_maximum") 

if __name__ == "__main__":
	# test de trouve_maximum
    print("début de la fonction main")
    print(trouve_maximum(120,2))
    print(trouve_maximum(2,10))
    
    # test de trouve_maximum 3
    # on teste les trois cas possibles 
    print(trouve_maximum(120,2,12))
    print(trouve_maximum(3,223,12))
    print(trouve_maximum(3,223,1200))
    print("fin de la fonction main")
