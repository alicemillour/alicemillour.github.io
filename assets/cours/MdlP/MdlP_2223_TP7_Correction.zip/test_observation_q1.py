# -*- coding: utf-8 -*-
from observation_q1 import *

if __name__ == "__main__":
    observation_1=Observation("Parc Naturel du Vexin","11/12", "Nadia Brea")
    observation_1.ajout_animal("sanglier")
    observation_1.ajout_vegetal("fougere")
    observation_1.ajout_vegetal("tulipe")
    print(observation_1)
