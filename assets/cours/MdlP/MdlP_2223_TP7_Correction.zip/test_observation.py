# -*- coding: utf-8 -*-
from observation import *

if __name__ == "__main__":
    observation_1 = Observation("Observation Naturel du Vexin","11/12", "Nadia Brea")
    
    # Construction d'instances d'animaux 
    ecu1 = Mammifere("foret","ecureuil", 4)
    sang1 = Mammifere("foret", "sanglier", 243)
    sang2 = Mammifere("chemin", "sanglier", 221)
    papillon = Insecte("foret", "papillon", False)
    
    L = [ecu1, sang1, sang2, papillon]
    
    # Construction d'instances de végétaux
    
    B1 = Vegetal("chemin","bolet", True)
    B2 = Vegetal("chemin","bolet", True)
    
    # ajout des animaux à l'observation 
    
    observation_1.ajout_vegetaux([B1,B2])
    observation_1.ajout_animaux(L)

    print(observation_1)
    
    papillon.capturer()    
    
    print(observation_1)
