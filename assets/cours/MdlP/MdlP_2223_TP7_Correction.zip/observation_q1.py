# -*- coding: utf-8 -*-

class Observation(object):
    def __init__(self, nom, date, obs):
        self.nom = nom
        self.date = date
        self.obs = obs
        self.liste_animaux = []
        self.liste_vegetaux = []        
        
    def __str__(self):
        # informations générales du Observation 
        ligne1 = "################### Infos générales : ###################"
        ligne2 = "#########################################################"
        en_tete = "{}\nNom du parc : {}\nDate : {} \nObservateur(trice) : {}\n{} ".format(ligne1, self.nom, self.date, self.obs, ligne2)
        
        # affichage des animaux 
        animaux = "Animaux : \n"
        for anim in self.liste_animaux:
            animaux += "- {}\n".format(anim)

        # affichage des végétaux
        vegetaux = "Végétaux : \n" 
        for veg in self.liste_vegetaux:
            vegetaux += "- {}\n".format(veg)
        
        return("{} \n{} \n{}{}").format(en_tete, animaux, vegetaux, ligne2)
    
    
    def ajout_animal(self, animal):
        self.liste_animaux.append(animal)
        
    def ajout_vegetal(self, vegetal):
        self.liste_vegetaux.append(vegetal)



        
