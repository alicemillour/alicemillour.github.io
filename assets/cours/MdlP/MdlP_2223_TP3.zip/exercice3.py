# -*- coding: utf-8 -*-
# Exercice conçu par Jean-Pascal Palus

import sys

def infos():
    print("""
            ===============================================
                            Jeu du pendu
            ===============================================
            """)
            
def get_mot():
    print("à compléter")
    
def pendu_run(mot):
    """
    Au début du jeu
        * Initialise la liste des lettres déjà devinées.
        * Initialise le nombre d'essais restant (généralement autour de 10).
        * Informe l'utilisateur de combien de lettres contient le mot à deviner.
        * Informe l'utilisateur de combien d'essais il dispose pour deviner le mot.
    """
    print("à compléter")
    
    
    
def print_mot(mot, lettres_devinees):
    """
    Affiche le mot à deviner en y révélant les lettres déjà devinées
    et en remplaçant les autres par '_'.
    """
    pass
            
if __name__ == "__main__":
    infos()
    
